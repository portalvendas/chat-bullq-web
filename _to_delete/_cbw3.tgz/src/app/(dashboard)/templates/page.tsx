'use client';

import { useState } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import {
  MessageSquareText,
  RefreshCw,
  Download,
  Loader2,
  Search,
  Trash2,
  Plus,
  Pencil,
  Send,
  ShieldCheck,
} from 'lucide-react';
import {
  templatesService,
  type WhatsappTemplate,
} from '@/features/templates/services/templates.service';
import { TemplateEditor } from '@/features/templates/components/template-editor';

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    APPROVED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    PENDING: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    REJECTED: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  const label: Record<string, string> = {
    APPROVED: 'Aprovado',
    PENDING: 'Pendente',
    REJECTED: 'Rejeitado',
  };
  return (
    <span
      className={`inline-block rounded px-2 py-0.5 text-[11px] font-medium ${
        map[status] ?? 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300'
      }`}
    >
      {label[status] ?? status}
    </span>
  );
}

export default function TemplatesPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<WhatsappTemplate | null>(null);
  const [creating, setCreating] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['wa-templates', search, page],
    queryFn: () => templatesService.list({ search, page, pageSize: 50 }),
    staleTime: 10_000,
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ['wa-templates'] });

  const seed = useMutation({
    mutationFn: () => templatesService.seed(),
    onSuccess: (r) => {
      if (r.seeded === 0 && r.errors && r.errors.length > 0) {
        toast.error(`Falha ao carregar: ${r.errors[0]}`);
      } else {
        toast.success(`${r.seeded} modelos aprovados carregados`);
      }
      invalidate();
    },
    onError: (e: any) =>
      toast.error(
        e?.response?.data?.message
          ? `Erro: ${e.response.data.message}`
          : 'Erro ao carregar modelos',
      ),
  });
  const sync = useMutation({
    mutationFn: () => templatesService.sync(),
    onSuccess: (r) => {
      if (r.channels === 0) {
        toast.info('Nenhum canal WhatsApp oficial conectado para sincronizar.');
      } else {
        toast.success(
          `${r.synced} modelos sincronizados da Meta` +
            (r.errors.length ? ` (${r.errors.length} canal com erro)` : ''),
        );
      }
      invalidate();
    },
    onError: () => toast.error('Erro ao sincronizar com a Meta'),
  });
  const remove = useMutation({
    mutationFn: (id: string) => templatesService.remove(id),
    onSuccess: () => invalidate(),
    onError: () => toast.error('Erro ao remover'),
  });
  const submit = useMutation({
    mutationFn: (id: string) => templatesService.submit(id),
    onSuccess: (r) => {
      toast.success(`Enviado à Meta como "${r.metaName}" — status ${r.status}`);
      invalidate();
    },
    onError: (e: any) =>
      toast.error(e?.response?.data?.message ?? 'Erro ao enviar para aprovação'),
  });

  const { data: health } = useQuery({
    queryKey: ['wa-health'],
    queryFn: () => templatesService.health(),
    staleTime: 60_000,
  });
  const healthChannels = health?.channels ?? [];

  const items: WhatsappTemplate[] = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-zinc-200 bg-white px-6 py-4 dark:border-zinc-800 dark:bg-zinc-950">
        <h1 className="inline-flex items-center gap-2 text-lg font-semibold text-zinc-900 dark:text-zinc-100">
          <MessageSquareText className="h-5 w-5 text-primary" />
          Modelos de chat
        </h1>
        <span className="text-sm text-zinc-400">{total} modelos</span>

        <div className="relative ml-auto">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
          <input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Pesquisar…"
            className="w-56 rounded-lg border border-zinc-300 bg-white py-1.5 pl-8 pr-3 text-sm outline-none focus:border-primary dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
        </div>
        <button
          onClick={() => seed.mutate()}
          disabled={seed.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
        >
          {seed.isPending ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <Download className="h-3.5 w-3.5" />
          )}
          Carregar aprovados
        </button>
        <button
          onClick={() => sync.mutate()}
          disabled={sync.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
        >
          {sync.isPending ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <RefreshCw className="h-3.5 w-3.5" />
          )}
          Sincronizar Meta
        </button>
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-medium text-white hover:opacity-90"
        >
          <Plus className="h-3.5 w-3.5" /> Novo modelo
        </button>
      </div>

      {healthChannels.length > 0 && (
        <div className="flex flex-wrap gap-3 border-b border-zinc-200 bg-zinc-50 px-6 py-2 text-xs dark:border-zinc-800 dark:bg-zinc-900/50">
          {healthChannels.map((c) => (
            <div
              key={c.channelId}
              className="inline-flex items-center gap-2 rounded-lg border border-zinc-200 bg-white px-2.5 py-1 dark:border-zinc-700 dark:bg-zinc-900"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              <span className="font-medium text-zinc-700 dark:text-zinc-200">
                {c.verifiedName || c.name}
              </span>
              {c.error ? (
                <span className="text-red-500">{c.error}</span>
              ) : (
                <>
                  <span className="text-zinc-400">·</span>
                  <span
                    className={
                      c.qualityRating === 'GREEN'
                        ? 'text-emerald-600'
                        : c.qualityRating === 'YELLOW'
                          ? 'text-amber-600'
                          : c.qualityRating === 'RED'
                            ? 'text-red-600'
                            : 'text-zinc-500'
                    }
                  >
                    qualidade: {c.qualityRating ?? '—'}
                  </span>
                  <span className="text-zinc-400">·</span>
                  <span className="text-zinc-500">limite: {c.messagingLimit ?? '—'}</span>
                </>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex items-center gap-2 p-8 text-sm text-zinc-500">
            <Loader2 className="h-4 w-4 animate-spin" /> Carregando…
          </div>
        ) : items.length === 0 ? (
          <div className="mx-auto mt-16 max-w-md rounded-xl border border-dashed border-zinc-200 px-8 py-16 text-center dark:border-zinc-800">
            <MessageSquareText className="mx-auto h-10 w-10 text-zinc-300 dark:text-zinc-600" />
            <p className="mt-3 text-sm text-zinc-500">
              Nenhum modelo ainda. Clique em <b>Carregar aprovados</b> para trazer
              os templates já aprovados pela Meta, ou <b>Sincronizar Meta</b> para
              puxar direto de um canal WhatsApp conectado.
            </p>
          </div>
        ) : (
          <table className="w-full border-collapse text-sm">
            <thead className="sticky top-0 z-10 bg-zinc-50 text-left text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:bg-zinc-900">
              <tr>
                <th className="px-4 py-2.5">Nome</th>
                <th className="px-4 py-2.5">Tipo</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5">Categoria</th>
                <th className="px-4 py-2.5">Idioma</th>
                <th className="px-4 py-2.5">ID WABA</th>
                <th className="px-4 py-2.5">Texto de resposta</th>
                <th className="px-4 py-2.5"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((t) => (
                <tr
                  key={t.id}
                  className="border-t border-zinc-100 align-top hover:bg-zinc-50/60 dark:border-zinc-800 dark:hover:bg-zinc-900/40"
                >
                  <td className="px-4 py-2.5 font-medium text-zinc-900 dark:text-zinc-100">
                    {t.name}
                  </td>
                  <td className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400">
                    WhatsApp
                  </td>
                  <td className="px-4 py-2.5">
                    <StatusBadge status={t.status} />
                    {t.status === 'REJECTED' && t.rejectionReason && (
                      <div
                        className="mt-1 max-w-[160px] truncate text-[10px] text-red-500"
                        title={t.rejectionReason}
                      >
                        {t.rejectionReason}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400">
                    {t.category === 'MARKETING'
                      ? 'Marketing'
                      : t.category === 'UTILITY'
                        ? 'Utilidade'
                        : t.category === 'AUTHENTICATION'
                          ? 'Autenticação'
                          : t.category}
                  </td>
                  <td className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400">
                    {t.language === 'pt_BR' ? 'Português (BR)' : t.language}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-[12px] text-zinc-500">
                    {t.waba ?? '—'}
                  </td>
                  <td className="max-w-md px-4 py-2.5 text-zinc-700 dark:text-zinc-300">
                    <span className="line-clamp-2">{t.bodyText}</span>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() =>
                          confirm(
                            `Enviar "${t.name}" para aprovação da Meta?`,
                          ) && submit.mutate(t.id)
                        }
                        disabled={submit.isPending}
                        title="Enviar para aprovação da Meta"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-zinc-400 hover:bg-emerald-50 hover:text-emerald-600 disabled:opacity-40 dark:hover:bg-emerald-900/20"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setEditing(t)}
                        className="flex h-7 w-7 items-center justify-center rounded-md text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() =>
                          confirm(`Remover o modelo "${t.name}"?`) && remove.mutate(t.id)
                        }
                        className="flex h-7 w-7 items-center justify-center rounded-md text-zinc-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-center gap-3 border-t border-zinc-200 py-2 text-xs text-zinc-500 dark:border-zinc-800">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="rounded px-2 py-1 hover:bg-zinc-100 disabled:opacity-40 dark:hover:bg-zinc-800"
          >
            Anterior
          </button>
          <span>
            Página {data.page} de {data.pages}
          </span>
          <button
            disabled={page >= data.pages}
            onClick={() => setPage((p) => p + 1)}
            className="rounded px-2 py-1 hover:bg-zinc-100 disabled:opacity-40 dark:hover:bg-zinc-800"
          >
            Próxima
          </button>
        </div>
      )}

      {(creating || editing) && (
        <TemplateEditor
          template={editing}
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSaved={() => {
            invalidate();
            setCreating(false);
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}

