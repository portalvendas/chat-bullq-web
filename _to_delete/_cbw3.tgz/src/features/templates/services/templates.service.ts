import { api } from '@/lib/api';

export interface WhatsappTemplate {
  id: string;
  name: string;
  status: string; // APPROVED | PENDING | REJECTED | ...
  category: string; // MARKETING | UTILITY | AUTHENTICATION
  language: string; // pt_BR
  waba: string | null;
  bodyText: string;
  source: string; // SEED | META_SYNC | MANUAL
  channelId: string | null;
  externalId: string | null;
  metaName?: string | null;
  rejectionReason?: string | null;
  components?: TemplateComponent[];
}

export type TemplateButton =
  | { type: 'QUICK_REPLY'; text: string }
  | { type: 'URL'; text: string; url: string }
  | { type: 'PHONE_NUMBER'; text: string; phone_number: string };

export type TemplateComponent =
  | { type: 'HEADER'; format: 'TEXT'; text: string }
  | { type: 'BODY'; text: string }
  | { type: 'FOOTER'; text: string }
  | { type: 'BUTTONS'; buttons: TemplateButton[] };

export interface ChannelHealth {
  channels: Array<{
    channelId: string;
    name: string;
    phone?: string;
    verifiedName?: string;
    qualityRating?: string;
    messagingLimit?: string;
    nameStatus?: string;
    error?: string;
  }>;
}

export interface TemplateListResult {
  items: WhatsappTemplate[];
  total: number;
  page: number;
  pageSize: number;
  pages: number;
}

function unwrap<T>(data: any): T {
  return (data?.data ?? data) as T;
}

export const templatesService = {
  async list(params: {
    page?: number;
    pageSize?: number;
    search?: string;
    status?: string;
  } = {}): Promise<TemplateListResult> {
    const { data } = await api.get('/whatsapp-templates', { params });
    return unwrap<TemplateListResult>(data);
  },
  async seed(): Promise<{ seeded: number; skipped?: number; errors?: string[] }> {
    const { data } = await api.post('/whatsapp-templates/seed', {});
    return unwrap(data);
  },
  async sync(): Promise<{
    synced: number;
    channels: number;
    errors: Array<{ channelId: string; error: string }>;
  }> {
    const { data } = await api.post('/whatsapp-templates/sync', {});
    return unwrap(data);
  },
  async create(dto: TemplateInput): Promise<WhatsappTemplate> {
    const { data } = await api.post('/whatsapp-templates', dto);
    return unwrap<WhatsappTemplate>(data);
  },
  async update(id: string, dto: Partial<TemplateInput>): Promise<WhatsappTemplate> {
    const { data } = await api.patch(`/whatsapp-templates/${id}`, dto);
    return unwrap<WhatsappTemplate>(data);
  },
  async remove(id: string): Promise<void> {
    await api.delete(`/whatsapp-templates/${id}`);
  },
  async submit(id: string): Promise<{ status: string; metaName: string }> {
    const { data } = await api.post(`/whatsapp-templates/${id}/submit`, {});
    return unwrap(data);
  },
  async health(): Promise<ChannelHealth> {
    const { data } = await api.get('/whatsapp-templates/health');
    return unwrap<ChannelHealth>(data);
  },
};

export interface TemplateInput {
  name: string;
  bodyText: string;
  waba?: string | null;
  status?: string;
  category?: string;
  language?: string;
  components?: TemplateComponent[];
}
