'use client';

/**
 * Painel de enriquecimento do lead — reutilizado no detalhe do card e no
 * painel de contato do inbox. Mostra:
 *  - Cabeçalho: DATA do lead + FONTE (Facebook, Instagram, Google, LP…)
 *  - Contato: nome, telefone, e-mail, tags
 *  - Tracking: utm_source/medium/campaign/content/term, fbclid, gclid,
 *    página, IP, user-agent
 *
 * A fonte é derivada de (nesta ordem): utm_source → metadata.source →
 * fbclid/gclid → canal da conversa. Nunca inventa: se não houver sinal,
 * mostra "Direto/Desconhecido".
 */
import { useState } from 'react';
import {
  Facebook,
  Instagram,
  Globe,
  Search,
  ShoppingBag,
  MessageCircle,
  Phone,
  Tag as TagIcon,
  Calendar,
  ChevronRight,
} from 'lucide-react';
import type {
  CardDetail,
  LeadTracking,
} from '../services/pipelines.service';

// ─── Derivação de fonte ──────────────────────────────────────────────

interface DerivedSource {
  label: string;
  Icon: typeof Facebook;
  cls: string;
}

function normalize(s: unknown): string {
  return String(s ?? '').trim().toLowerCase();
}

export function deriveLeadSource(
  tracking: LeadTracking,
  metaSource?: unknown,
  channelType?: string,
): DerivedSource {
  const utm = normalize(tracking.utm_source);
  const src = normalize(metaSource ?? tracking.source);
  const hasFb = !!tracking.fbclid;
  const hasG = !!tracking.gclid;
  const chan = normalize(channelType);

  const fb: DerivedSource = {
    label: 'Facebook',
    Icon: Facebook,
    cls: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  };
  const ig: DerivedSource = {
    label: 'Instagram',
    Icon: Instagram,
    cls: 'bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400',
  };
  const google: DerivedSource = {
    label: 'Google',
    Icon: Search,
    cls: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  };
  const lp: DerivedSource = {
    label: 'Landing Page',
    Icon: Globe,
    cls: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  };

  // 1) utm_source explícito
  if (utm) {
    if (utm.includes('insta') || utm === 'ig') return ig;
    if (
      utm.includes('meta') ||
      utm.includes('face') ||
      utm === 'fb' ||
      utm.includes('fban') ||
      utm.includes('fbads')
    )
      return fb;
    if (utm.includes('google') || utm.includes('gads') || utm.includes('adwords'))
      return google;
    // utm_source livre (ex.: newsletter, parceiro): mostra como veio.
    return {
      label: tracking.utm_source as string,
      Icon: Globe,
      cls: 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300',
    };
  }

  // 2) metadata.source (origem interna)
  if (src) {
    if (src.includes('landing') || src === 'lp') return lp;
    if (src.includes('facebook') || src.includes('leadads') || src.includes('meta'))
      return { ...fb, label: 'Facebook Lead Ads' };
    if (src.includes('insta')) return ig;
    if (src.includes('mercado'))
      return {
        label: 'Mercado Livre',
        Icon: ShoppingBag,
        cls: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
      };
    if (src.includes('shopee'))
      return {
        label: 'Shopee',
        Icon: ShoppingBag,
        cls: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
      };
  }

  // 3) sinais de clique
  if (hasFb) return fb;
  if (hasG) return google;

  // 4) canal da conversa como último recurso
  if (chan.includes('instagram')) return ig;
  if (chan.includes('whatsapp') || chan.includes('zappfy'))
    return {
      label: 'WhatsApp',
      Icon: Phone,
      cls: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
    };
  if (chan.includes('mercado'))
    return {
      label: 'Mercado Livre',
      Icon: ShoppingBag,
      cls: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
    };
  if (chan.includes('shopee'))
    return {
      label: 'Shopee',
      Icon: ShoppingBag,
      cls: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
    };

  return {
    label: 'Direto / Desconhecido',
    Icon: MessageCircle,
    cls: 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300',
  };
}

function getTracking(card: CardDetail): LeadTracking {
  const fromContact = (card.contact?.metadata as any)?.tracking;
  const fromCard = (card.metadata as any)?.tracking;
  return (fromContact ?? fromCard ?? {}) as LeadTracking;
}

function getMetaSource(card: CardDetail): unknown {
  return (
    (card.contact?.metadata as any)?.source ?? (card.metadata as any)?.source
  );
}

function fmtDate(iso?: string | null): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '—';
  }
}

// ─── Cabeçalho (Data + Fonte) ────────────────────────────────────────

export function LeadHeader({ card }: { card: CardDetail }) {
  const tracking = getTracking(card);
  const source = deriveLeadSource(
    tracking,
    getMetaSource(card),
    card.conversation?.channel?.type,
  );
  const { Icon } = source;
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-zinc-200 bg-zinc-50 px-3 py-2 dark:border-zinc-800 dark:bg-zinc-900/50">
      <span className="inline-flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-300">
        <Calendar className="h-3.5 w-3.5 text-zinc-400" />
        Lead em <strong className="font-medium">{fmtDate(card.createdAt)}</strong>
      </span>
      <span
        className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${source.cls}`}
        title="Fonte do lead"
      >
        <Icon className="h-3 w-3" />
        {source.label}
      </span>
    </div>
  );
}

// ─── Bloco completo de enriquecimento ────────────────────────────────

function Field({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div className="flex flex-col">
      <span className="text-[10px] uppercase tracking-wide text-zinc-400">
        {label}
      </span>
      <span className="break-words text-xs text-zinc-800 dark:text-zinc-200">
        {value}
      </span>
    </div>
  );
}

function humanizeKey(k: string): string {
  return k.replace(/_/g, ' ').replace(/^./, (m) => m.toUpperCase());
}

export function LeadEnrichment({ card }: { card: CardDetail }) {
  const c = card.contact;
  const tracking = getTracking(card);
  // Campos personalizados gravados no import (metadata.custom).
  const customObj = ((card.metadata as any)?.custom ?? {}) as Record<string, any>;
  const customEntries = Object.entries(customObj).filter(
    ([, v]) => v !== null && v !== undefined && v !== '',
  );

  // Lead score + temperatura + respostas do formulário (LP/Lead Ads gravam em
  // metadata.raw + leadScore/leadTemperature). Para lead que digitou no
  // WhatsApp não há captura estruturada — as respostas ficam no próprio chat.
  const meta = (card.metadata as any) ?? {};
  const raw = (meta.raw ?? {}) as Record<string, any>;
  const score = meta.leadScore ?? raw.lead_score ?? raw.score ?? null;
  const temp =
    meta.leadTemperature ?? raw.lead_temperatura ?? raw.temperatura ?? null;
  const tempCls =
    temp === 'Quente'
      ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
      : temp === 'Morno'
        ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300'
        : temp === 'Frio'
          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
          : 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300';
  const fmtVal = (v: any) =>
    Array.isArray(v)
      ? v.join(', ')
      : typeof v === 'boolean'
        ? v
          ? 'Sim'
          : 'Não'
        : v == null
          ? ''
          : String(v);
  const FORM_FIELDS: [string, string][] = [
    ['itens', 'Itens'],
    ['material', 'Material'],
    ['medidas', 'Medidas'],
    ['quantidade', 'Quantidade'],
    ['prazo', 'Prazo'],
    ['cidade_uf', 'Cidade/UF'],
    ['cidade', 'Cidade'],
    ['precisa_consultoria', 'Consultoria'],
    ['item_outro', 'Outro item'],
    ['descricao', 'Descrição'],
  ];
  const formEntries = FORM_FIELDS.map(
    ([k, label]) => [label, fmtVal(raw[k])] as [string, string],
  ).filter(([, v]) => v !== '');
  // Resumo do formulário também vem na DESCRIÇÃO do card (ex.: "Itens: … |
  // Material: … | Score: 51 (Morno)") — é o que o card sem conversa mostra.
  const description = card.description?.trim() || '';
  const hasFormBlock =
    score != null || formEntries.length > 0 || description.length > 0;
  // Rastreamento vem RECOLHIDO por padrão — o operador expande se quiser ver.
  const [showTracking, setShowTracking] = useState(false);
  const trackingKeys = Object.keys(tracking).filter(
    (k) => tracking[k] !== undefined && tracking[k] !== '' && tracking[k] !== null,
  );
  const hasTracking = trackingKeys.length > 0;
  // Chaves já exibidas com rótulo fixo abaixo; o resto (ex.: "projeto") é
  // renderizado dinamicamente pra não sumir nenhum campo enviado no tracking.
  const KNOWN_TRACKING = new Set([
    'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term',
    'fbclid', 'gclid', 'client_ip', 'pagina', 'referrer', 'user_agent',
  ]);
  const extraTrackingEntries = trackingKeys
    .filter((k) => !KNOWN_TRACKING.has(k))
    .map((k) => [k, tracking[k]] as [string, any]);

  return (
    <div className="space-y-3">
      {/* Contato */}
      <div className="rounded-md border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900/40">
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
          Contato
        </p>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Nome" value={c?.name} />
          <Field label="Telefone" value={c?.phone} />
          <Field label="E-mail" value={c?.email} />
        </div>
        {c?.tags && c.tags.length > 0 && (
          <div className="mt-2 flex flex-wrap items-center gap-1">
            <TagIcon className="h-3 w-3 text-zinc-400" />
            {c.tags.map((t) => (
              <span
                key={t.id}
                className="rounded-full px-2 py-0.5 text-[10px] font-medium"
                style={{ backgroundColor: `${t.color}22`, color: t.color }}
              >
                {t.name}
              </span>
            ))}
          </div>
        )}
        {!c?.email && !c?.phone && !c?.name && (
          <p className="text-xs text-zinc-400">Sem dados de contato.</p>
        )}
      </div>

      {/* Score + Respostas do formulário (lead da LP / Lead Ads) */}
      {hasFormBlock && (
        <div className="rounded-md border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900/40">
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
              Respostas do formulário
            </p>
            {score != null && (
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${tempCls}`}
                title="Lead score / temperatura"
              >
                Score {String(score)}
                {temp ? ` · ${temp}` : ''}
              </span>
            )}
          </div>
          {formEntries.length > 0 ? (
            <div className="grid grid-cols-2 gap-2">
              {formEntries.map(([label, value]) => (
                <Field key={label} label={label} value={value} />
              ))}
            </div>
          ) : description ? (
            <p className="whitespace-pre-wrap break-words text-xs text-zinc-800 dark:text-zinc-200">
              {description}
            </p>
          ) : (
            <p className="text-xs text-zinc-400">
              Sem respostas estruturadas (lead digitou no chat).
            </p>
          )}
        </div>
      )}

      {/* Campos personalizados (import) */}
      {customEntries.length > 0 && (
        <div className="rounded-md border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900/40">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
            Campos personalizados
          </p>
          <div className="grid grid-cols-2 gap-2">
            {customEntries.map(([k, v]) => (
              <Field key={k} label={humanizeKey(k)} value={String(v)} />
            ))}
          </div>
        </div>
      )}

      {/* Tracking — recolhido por padrão */}
      <div className="rounded-md border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/40">
        <button
          type="button"
          onClick={() => setShowTracking((v) => !v)}
          disabled={!hasTracking}
          className="flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-left hover:bg-zinc-50 disabled:cursor-default disabled:hover:bg-transparent dark:hover:bg-zinc-800/50"
        >
          <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
            <ChevronRight
              className={`h-3.5 w-3.5 transition-transform ${showTracking ? 'rotate-90' : ''}`}
            />
            Rastreamento (tracking)
          </span>
          <span className="text-[10px] font-normal normal-case text-zinc-400">
            {hasTracking ? `${trackingKeys.length} campos` : 'nenhum dado'}
          </span>
        </button>
        {showTracking && hasTracking && (
          <div className="grid grid-cols-2 gap-2 px-3 pb-3 pt-1">
            <Field label="utm_source" value={tracking.utm_source} />
            <Field label="utm_medium" value={tracking.utm_medium} />
            <Field label="utm_campaign" value={tracking.utm_campaign} />
            <Field label="utm_content" value={tracking.utm_content} />
            <Field label="utm_term" value={tracking.utm_term} />
            <Field label="fbclid" value={tracking.fbclid} />
            <Field label="gclid" value={tracking.gclid} />
            <Field label="IP" value={tracking.client_ip} />
            <div className="col-span-2">
              <Field label="Página" value={tracking.pagina} />
            </div>
            <div className="col-span-2">
              <Field label="Referrer" value={tracking.referrer} />
            </div>
            <div className="col-span-2">
              <Field label="User-Agent" value={tracking.user_agent} />
            </div>
            {/* Chaves extras (ex.: projeto) enviadas no tracking. */}
            {extraTrackingEntries.map(([k, v]) => (
              <div key={k} className="col-span-2">
                <Field label={humanizeKey(k)} value={String(v)} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
